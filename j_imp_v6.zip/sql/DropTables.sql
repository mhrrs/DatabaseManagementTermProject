-- Developed by Michael Harris 
use Pizzeria;
DROP schema Pizzeria;