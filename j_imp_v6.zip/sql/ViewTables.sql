-- Developed by Michael Harris 
USE Pizzeria;
SELECT * FROM Pizzeria.pizza;
SELECT * FROM Pizzeria.topping;
SELECT * FROM Pizzeria.pizzatopping;
SELECT * FROM Pizzeria.basepricepizza;
SELECT * FROM Pizzeria.discount;
SELECT * FROM Pizzeria.orders;
SELECT * FROM Pizzeria.delivery;
SELECT * FROM Pizzeria.pickup;
SELECT * FROM Pizzeria.dinein;
SELECT * FROM Pizzeria.pizzaorder;
SELECT * FROM Pizzeria.pizzadiscount;
SELECT * FROM Pizzeria.odiscount;